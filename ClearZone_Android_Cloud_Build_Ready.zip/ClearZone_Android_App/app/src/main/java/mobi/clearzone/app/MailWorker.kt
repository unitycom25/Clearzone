package mobi.clearzone.app
import android.content.Context
import androidx.work.*
import kotlinx.coroutines.*
class MailWorker(appContext:Context,params:WorkerParameters):CoroutineWorker(appContext,params){ override suspend fun doWork():Result=withContext(Dispatchers.IO){ try{MailPoller.notifyWhenNeeded(applicationContext);Result.success()}catch(_:Throwable){Result.retry()} } }
