package mobi.clearzone.app
import android.Manifest
import android.annotation.SuppressLint
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.view.View
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.*
import mobi.clearzone.app.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit
class MainActivity:AppCompatActivity(){
 private lateinit var b:ActivityMainBinding
 private val h=Handler(Looper.getMainLooper())
 private val tick=object:Runnable{override fun run(){Thread{try{saveCookie();MailPoller.notifyWhenNeeded(this@MainActivity)}catch(_:Throwable){}}.start();h.postDelayed(this,60000)}}
 private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 @SuppressLint("SetJavaScriptEnabled") override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityMainBinding.inflate(layoutInflater);setContentView(b.root);window.statusBarColor=Color.rgb(5,7,5);window.navigationBarColor=Color.rgb(5,7,5);NotificationHelper.createChannel(this);requestNotifications();scheduleWorker()
  CookieManager.getInstance().apply{setAcceptCookie(true);setAcceptThirdPartyCookies(b.webView,true)}
  b.webView.settings.apply{javaScriptEnabled=true;domStorageEnabled=true;databaseEnabled=true;cacheMode=WebSettings.LOAD_DEFAULT;mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;userAgentString="$userAgentString ClearZoneAndroid/1.0";allowFileAccess=false;allowContentAccess=true}
  b.webView.webChromeClient=WebChromeClient();b.webView.webViewClient=object:WebViewClient(){override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean{val host=r.url.host.orEmpty();return if(host=="clearzone.mobi"||host.endsWith(".clearzone.mobi"))false else{startActivity(Intent(Intent.ACTION_VIEW,r.url));true}};override fun onPageFinished(v:WebView,u:String){b.splash.animate().alpha(0f).setDuration(220).withEndAction{b.splash.visibility=View.GONE}.start();saveCookie()}}
  b.webView.loadUrl(if(intent.getBooleanExtra("open_mail",false))"${AppConfig.BASE_URL}/public/pda/dialogues.php" else AppConfig.START_URL)
  onBackPressedDispatcher.addCallback(this,object:OnBackPressedCallback(true){override fun handleOnBackPressed(){if(b.webView.canGoBack())b.webView.goBack()else finish()}})
 }
 override fun onResume(){super.onResume();h.removeCallbacks(tick);h.post(tick)}
 override fun onPause(){saveCookie();h.removeCallbacks(tick);super.onPause()}
 override fun onDestroy(){h.removeCallbacks(tick);b.webView.stopLoading();b.webView.destroy();super.onDestroy()}
 override fun onNewIntent(i:Intent){super.onNewIntent(i);if(i.getBooleanExtra("open_mail",false))b.webView.loadUrl("${AppConfig.BASE_URL}/public/pda/dialogues.php")}
 private fun saveCookie(){val c=CookieManager.getInstance().getCookie(AppConfig.BASE_URL).orEmpty();if(c.isNotBlank())getSharedPreferences(AppConfig.PREFS,MODE_PRIVATE).edit().putString(AppConfig.PREF_COOKIE,c).apply()}
 private fun requestNotifications(){if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permission.launch(Manifest.permission.POST_NOTIFICATIONS)}
 private fun scheduleWorker(){val r=PeriodicWorkRequestBuilder<MailWorker>(15,TimeUnit.MINUTES).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("clearzone_mail",ExistingPeriodicWorkPolicy.UPDATE,r)}
}
