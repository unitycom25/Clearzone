package mobi.clearzone.app
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.*
object NotificationHelper {
 fun createChannel(context:Context){ if(Build.VERSION.SDK_INT>=26){ context.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(AppConfig.CHANNEL_ID,AppConfig.CHANNEL_NAME,NotificationManager.IMPORTANCE_HIGH).apply{description="Новые сообщения в PDA";enableVibration(true)}) } }
 fun show(context:Context,title:String,text:String,id:Int){
  if(Build.VERSION.SDK_INT>=33 && ActivityCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
  val intent=Intent(context,MainActivity::class.java).putExtra("open_mail",true).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
  val pi=PendingIntent.getActivity(context,id.coerceAtLeast(1),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val n=NotificationCompat.Builder(context,AppConfig.CHANNEL_ID).setSmallIcon(R.drawable.ic_radiation).setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build()
  NotificationManagerCompat.from(context).notify(4101,n)
 }
}
