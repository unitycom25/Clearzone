package mobi.clearzone.app
import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
object MailPoller {
 data class Result(val authorized:Boolean,val unread:Int,val latestId:Int,val sender:String,val preview:String)
 fun check(context:Context):Result?{
  val prefs=context.getSharedPreferences(AppConfig.PREFS,Context.MODE_PRIVATE)
  val cookie=prefs.getString(AppConfig.PREF_COOKIE,"").orEmpty(); if(cookie.isBlank())return null
  val c=(URL(AppConfig.NOTIFICATION_URL).openConnection() as HttpURLConnection).apply{requestMethod="GET";connectTimeout=8000;readTimeout=8000;setRequestProperty("Accept","application/json");setRequestProperty("User-Agent","ClearZone-Android/1.0");setRequestProperty("Cookie",cookie);useCaches=false}
  return try{ val body=c.inputStream.bufferedReader(Charsets.UTF_8).use{it.readText()}; val j=JSONObject(body); Result(j.optBoolean("authorized",false),j.optInt("unread",0),j.optInt("latest_id",0),j.optString("sender","Новая почта"),j.optString("preview","В PDA пришло новое сообщение.")) } finally { c.disconnect() }
 }
 fun notifyWhenNeeded(context:Context){
  val prefs=context.getSharedPreferences(AppConfig.PREFS,Context.MODE_PRIVATE); val r=check(context)?:return; if(!r.authorized)return
  val oldId=prefs.getInt(AppConfig.PREF_LAST_MESSAGE_ID,0); val oldUnread=prefs.getInt(AppConfig.PREF_LAST_UNREAD,0)
  if(r.latestId>0 && (r.latestId>oldId || r.unread>oldUnread)) NotificationHelper.show(context,"Сообщение от ${r.sender}",r.preview,r.latestId)
  prefs.edit().putInt(AppConfig.PREF_LAST_MESSAGE_ID,r.latestId).putInt(AppConfig.PREF_LAST_UNREAD,r.unread).apply()
 }
}
