package mobi.clearzone.app
object AppConfig {
 const val BASE_URL="https://clearzone.mobi"
 const val START_URL="$BASE_URL/"
 const val NOTIFICATION_URL="$BASE_URL/public/api/app_notifications.php"
 const val PREFS="clearzone_app"
 const val PREF_COOKIE="session_cookie"
 const val PREF_LAST_MESSAGE_ID="last_message_id"
 const val PREF_LAST_UNREAD="last_unread"
 const val CHANNEL_ID="clearzone_mail"
 const val CHANNEL_NAME="Почта ClearZone"
}
