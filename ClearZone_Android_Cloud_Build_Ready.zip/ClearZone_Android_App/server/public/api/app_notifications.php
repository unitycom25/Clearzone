<?php
declare(strict_types=1);
require_once $_SERVER['DOCUMENT_ROOT'].'/private/core.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
function app_json(array $data,int $status=200):never{http_response_code($status);echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
if(empty($id)||empty($users)||(int)$id<=0){app_json(['authorized'=>false,'unread'=>0,'latest_id'=>0],401);}
$unread=(int)(DB::val('SELECT COUNT(*) FROM `messages` WHERE `addressee`=? AND `readed`=0 AND `addressee_delete`=0',[(int)$id])?:0);
$latest=DB::row('SELECT m.`id`,m.`message`,m.`date`,u.`login` FROM `messages` m LEFT JOIN `users` u ON u.`id`=m.`sender` WHERE m.`addressee`=? AND m.`readed`=0 AND m.`addressee_delete`=0 ORDER BY m.`date` DESC,m.`id` DESC LIMIT 1',[(int)$id]);
$preview='';if($latest){$preview=trim(preg_replace('/\s+/u',' ',strip_tags((string)$latest['message']))??'');if(mb_strlen($preview,'UTF-8')>140)$preview=mb_substr($preview,0,137,'UTF-8').'…';}
app_json(['authorized'=>true,'unread'=>$unread,'latest_id'=>(int)($latest['id']??0),'sender'=>(string)($latest['login']??'Система'),'preview'=>$preview!==''?$preview:'В PDA появилось новое сообщение.','time'=>(int)($latest['date']??0)]);
